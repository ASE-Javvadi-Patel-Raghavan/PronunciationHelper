/** Automatically generated file. DO NOT MODIFY */
package edu.example.test;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}